---
id: "upcoming-nv_murb86h3_5_mbj0dk5c"
kind: "plan"
title: "往后几章"
---

- Rhea opens the sealed letter.
- Rider reveals a clue.