# Android 追齐 iOS 执行台账

实施依据：[调研](/Users/mi/Downloads/AI/AmberAgent/android/docs/audits/2026-09-09-android-ios-parity-research.md)与[工作包计划](/Users/mi/Downloads/AI/AmberAgent/android/docs/plans/2026-09-09-android-ios-parity-plan.md)。用户已授权连续实施、每阶段 subagent review 并修复，不需要再次确认。

## 阶段与完成门

| Phase | 交付范围 | 必须闭合的结果 | 状态 |
| --- | --- | --- | --- |
| 0 基线与执行计划 | W01；固定工作树、测试入口、UI 验证环境；完善阶段依赖 | 用户 WIP 可识别；每个工作包归属明确；subagent 核查计划与证据边界 | 完成，复审通过 |
| 1 日常反馈与写入契约 | W02/W03/W05 | 模型刷新、发送配置、附件/历史/搜索反馈、任务写入和记忆 CAS 有实际消费者与定点回归 | 完成，逻辑/UI 复审及设备验收通过 |
| 2 继续工作与数据恢复 | W15 契约 → W04 路由骨架 → W14 owner → 路由验收；W06 | 精确路由、恢复重试/隔离、小说中断恢复；真实交换契约与已支持范围验证 | 完成，逻辑/UI/迁移复审通过 |
| 3 子代理与浏览器 | W07/W08/W09 | 编排与任务卡、同会话接管/交还、弹窗/动作回执、站点确认 | 完成，逻辑/UI/设备复审通过 |
| 4 小应用系统能力 | W10/W11；W18 的 Q03/Q04/Q05 | bridge 到系统 owner、权限、生命周期闭环；未保存退出与错误恢复 | 用户主动暂停，部分UI改动待验证 |
| 5 账号、系统入口与终端 | W12/W13/W16/W17 | 登录请求、日历/快捷入口/试听、managed SSH 真实接线 | 待实施 |
| 6 手机产品集成 | W19 手机集成子集；Q08/Q10 最终核查；D01–D20/Q01–Q11 | 手机构建、升级、跨模块旅程、UI 视觉/语义检查 | 待实施 |
| 7 系统生态扩展 | E02 健康摘要、提醒/闹钟、运动计划 | 按 Android 可用系统能力完成等效用户流程，明确数据来源 | 待实施 |
| 8 可穿戴伴侣 | E01 | 手机 owner、可靠交接、草稿/结果/任务与受限操作 | 待实施 |
| 9 全产品收口 | E03 平台适配；W19 全产品最终回归 | 手机/可穿戴构建、交接、升级、UI 及未支持范围逐项核验 | 待实施 |

所有阶段都必须经过独立 subagent review，重点检查：入口→配置→执行 owner→持久化；取消/失败/返回后的下一动作；布局错位、对齐、边距、控件大小、字体缩放与语义。review 只提出可定位问题，不将假设风险强行改成抽象层、泛化重试或额外兜底。主 agent 整合并修复，定点复验后再进入下阶段。

W01 的旅程数据随实际功能补齐，不先搭建庞大模拟框架。W15 除验证外，若发现明确的交换契约缺口，补最小可工作的交换实现并验证；不以旧 JSON 测试冒充当前工作区互通。W17 优先复用已有运行时/客户端，不能自行实现 SSH 协议。E01/E02 在 Phase 7/8 继续执行，Phase 6 只表示手机主线完成。交互 PTY 是原计划的可选新增范围，managed SSH 第一版仍如实声明非 PTY。

Q10 的单项开关在其 owner 所属阶段评估：SyncProvider 随 W06、ThreadGraph 随 W07，Phase 6 最终检查。Q08 在运行恢复验证后处理。阶段内可并行，跨阶段必须通过 review 门。

## 实施约束

- Android 初始 HEAD `ab984f6df1d6b5f9bae2b007ccdcf43f1d467e62`，39 个已有 tracked WIP；原始 diff 与文件摘要保存于 `/tmp/amber-parity-start.patch`、`/tmp/amber-parity-start-files.json`，只用于区分改动，不自动回滚。
- iOS 对照 HEAD `1023e8a08f5957157226725b43dbf3e2e7078a17`，只读授权持续有效。
- Ponytail full 已在本会话激活，不重复加载。复用现有 owners/Compose/Room/WorkManager，禁止过度设计。
- 多 agent 实现按文件边界分工，测试/构建由主 agent 串行运行，避免 Gradle 输出互相覆盖；review 与实现角色分开。
- 每条差距记录为待实施、实现/静态通过、运行通过或尚未验证；没有设备/真实账号时不能把源码通过写成真机通过。
- 不自动提交或发布，不新增依赖，不覆盖无关 WIP。

## 阶段记录

### Phase 0

- 已固定初始 WIP，与前一轮基线一致；此前 83 项定点单测通过。
- UI 基线：`./gradlew :app:testDebugUnitTest --tests app.amber.feature.ui.components.ai.ModelMenuInteractionTest --tests app.amber.feature.ui.components.ai.ComposerInteractionTest --offline --console=plain`，5+4 共 9 项通过，0 失败/跳过。日志 `/tmp/amber-parity-phase0-ui.log`。
- 设备：AVD `od_mobile_test`，`emulator-5554`，API 35，1080×2400，420dpi；以只读、不保存快照方式启动，可 adb 截图/操作，不影响原 AVD 保存数据。
- 已有 APK：`app/build/outputs/apk/debug/app-arm64-v8a-debug.apk`，metadata variant=debug、package=`app.amber.agent.graphite`、version=2.6.8/396；已安装并启动。它是既有产物，不能证明对应当前源码，Phase 1 将重新构建。
- 合成输入复用现有 Compose 模型菜单/输入门 fixture；后续旅程按所属阶段增加。
- review：`/root/phase0_review` 检查了覆盖、依赖、WIP、UI 证据和范围。已补记录模板、W18 归属、Phase 2 顺序、Phase 7/8 全产品扩展及硬 review 门，等待针对性复审。

## 每阶段 review 记录模板

每阶段记录 reviewer 子任务名及报告、实际调用链与持久状态、失败/取消/返回路径、UI 几何/语义与截图、测试命令/结果、主 agent 修复条目及复验/复审结论。静态、JVM、合成 fixture、模拟器、真实账号证据分别记录。review 未通过不得进入下一阶段；外部不可验证项不得标为验证通过。

初始 WIP patch SHA-256：`f000760804b534bf17f31e7f23a6dcef759a35b3f4beda609946540e7def321f`。文件路径与 SHA 保存在 [基线记录](/Users/mi/Downloads/AI/AmberAgent/android/docs/audits/2026-09-09-parity-wip-baseline.json)，不含源码/凭据。

Phase 0 实屏证据：[首页截图](/Users/mi/Downloads/AI/AmberAgent/android/docs/audits/parity-artifacts/phase0-home.png)。启动完成，空会话首页、功能轨与新建按钮可见；这是既有 APK 的基线，不当作之后代码的视觉验收。

Phase 0 复审：`/root/phase0_review` 已通过，基线截图未发现明确布局阻断；已区分 W19 手机子集与全产品最终回归。Phase 1 开始：模型候选、附件、历史搜索、任务持久化、记忆 CAS 按文件边界由五个实现 subagent 并行，主 agent 负责发送配置提示、集成与统一验证。

### Phase 1（完成）

- 实现分工：`phase1_models`、`phase1_attachments`、`phase1_history`、`phase1_taskstore`、`phase1_memory`；主线实现 ChatConfigurationIssue/Hint 与聊天发送前修复入口。
- 当前已落码：模型候选与选择分离、刷新失败原位重试/旧响应隔离；历史与全文搜索错误、首页标题筛选；任务原子快照/先持久化再发布/清理旧错误；记忆编辑删除 CAS、保留草稿和最新版本；发送配置持续提示。
- 集成修正：删除任务重复落盘；记忆状态 API 设为 internal、保存中禁止继续编辑、最新版本读取失败不冒充已删除；模型请求切换清除旧投影、使用最新 provider 防覆盖配置。
- 任务存储最初 5 项回归及删除重复落盘后的复验均通过（`/tmp/amber-parity-phase1-taskstore.log`）；之后增加损坏记录保留、首次注册失败不发布两项，待下一轮统一验证。
- 首轮 app 编译捕获附件接口/资源尚未完成和首页 StateFlow 未 collect；反馈对应实现者。该次未进入测试，不计通过（`/tmp/amber-parity-phase1-app.log`）。
- 独立 review 已启动：`phase0_review` 检查逻辑/持久化/调用链，`phase1_ui_review` 检查页面状态和布局。仍需修复报告、完整测试、新 APK 模拟器截图与复审，尚未通过阶段门。
- 第二轮 app 编译通过，30 项测试中 29 通过；唯一失败为新增 MemoryCasTest 的 Int/nullable Long 比较，已改为 Long 常量。配置判定 6 项、窄屏/大字体配置提示 2 项通过。后续补丁新增了异步查询和更多附件测试，须重新统计最终结果。
- APK 已在关闭本次 KSP 增量生成后构建通过（51 秒）；此前增量模式失败为 `Unexpected owner function: null`。未修改构建配置；后续验证临时带 `-Pksp.incremental=false`。只读模拟器旧测试 APK 签名不同，移除该空测试安装后成功安装当前构建。
- 实屏证据已保存 `parity-artifacts/phase1-home.png`、`phase1-home-search.png`、`phase1-chat-config.png`、`phase1-model-repair.png`。首页内联筛选/无结果/键盘可用，配置提示无重叠，缺模型修复可进入服务商配置。这些为本阶段中间构建，最终补丁仍需重装复核。
- UI review 已修：长按建议/生成组件/MiniApp 修改/再生成/生成图片修改复用配置判定；无可用模型的空菜单修复入口；取消编辑只删除新导入的附件，成功发送保留附件；待命缩略图短文案与无障碍状态；模型整行选择与 Current 点击区；记忆新增入口与说明按钮同时可见、编辑内容可滚动。
- 独立逻辑 review `phase0_review` 首次结论不通过：新增记忆分类/置顶未提交、底层 FTS 吞异常、同 provider OAuth 账号切换候选缓存、Gemini 登录旧快照覆盖。已交各 owner 定向修复；补查 ProviderConfigTools Codex 登录状态与 Cron 完成清理错误字段。未将未通过的阶段提前标记完成。
- W19 本地化补充：英语 locale 下旧页面仍混用硬编码中文（首页轨道、provider identity 等），Phase 6 统一核查；Phase 1 新增资源持续提供 en/zh。

- 最终统一定点回归 59 项通过（app 52 + task 7；`/tmp/amber-parity-phase1-final-tests.log`）；另跑 ProviderConfigTools 34 项、模型候选 5 项通过（后者与前批重复），日志 `/tmp/amber-parity-phase1-auth-build.log`。
- 实屏补发现损坏 PDF 返回另一种解析失败字符串。精确兼容现有 parser 错误信号，补本地化说明和 3 项回归，通过日志 `/tmp/amber-parity-phase1-pdf-final.log`。最终实屏 `parity-artifacts/phase1-pdf-read-failed.png` 显示红色 Text read failed，普通文本 143B 导入已验证。
- 大字体 1.5 倍实屏补发现分类按钮 pill 裁字及长编辑弹窗 Save 被 IME 覆盖。只修改该按钮 shape 和编辑 Dialog IME insets；最终 assembleDebug 通过（`/tmp/amber-parity-phase1-ime-build.log`），已安装对应 APK 复验，字体比例已恢复 1.0。
- 合成记忆从新增→选择 Core→置顶→保存→重新打开，Core/Pinned/来源/更新时间均正确；大字体+IME 可滚动至分类和置顶，Save/Cancel 始终可见。最终图：`phase1-memory-large.png`、`phase1-memory-large-ime.png`、`phase1-memory-large-ime-bottom.png`；同目录另存新增入口、默认弹窗、保存后列表和待命卡。
- 独立逻辑 reviewer `phase0_review` 定向复审全部阻断及 Codex 状态脱敏、附件错误链路，均通过。独立 UI reviewer `phase1_ui_review` 对最终截图及实际 modifier 复审通过；没有将紧凑但无重叠的分类行强行修改。
- Phase 1 证据合计 96 项不同测试（59 + ProviderConfigTools 34 + attachment warning 3），0 失败；模型候选额外 5 项复跑不重复计数。未使用真实 OAuth 账号/在线生成，不把本地状态测试写成账号登录实测。

### Phase 2（完成）

先完成 W15 真实两端 exporter/importer 契约证据与明确缺口，再推进 W04 路由骨架、W14 小说恢复 owner 和路由验收；W06 备份恢复可独立并行。各实现者保持文件边界，统一 Gradle 由主任务运行，阶段末逻辑与 UI 分别 review。

- 阶段内依赖细化：W15 真实 Novel 交换、对话交换分别由 `phase2_exchange`、`phase2_conversation_exchange` 负责；`phase2_restore` 独立实施 W06；`phase2_routes` 负责非 Novel W04。主线只修改 Android 本地 `.amber/jobs` 的恢复 owner 与精确路由，不改变 W15 交换树；交换实证仍为本阶段验收门。
- 定向事实核查 `runtime_audit` 确认已有 execution CAS、commit 前缓冲、ledger 后保留和进度去重，无需重写。模型输出在 commit 前没有 durable payload，进程被杀后不自动重放；脏正文继续由现有 worker 预检明确失败。
- 主线已补：WorkManager 入队 Operation 完成后才返回、controller mutation/恢复查询串行、应用启动和项目页 reconcile、损坏 job 名称保留并进入 UI；显式 branch/job 归属验证，完成/取消批次不会显示正在运行。
- 首批 Novel recovery 5 项通过；初测两项因现有 wire 时间精度为秒而直接比较纳秒失败，已按既有 wire 精度修正断言，未改变持久格式。新增 route fixture 和真实 WorkManager 入队/异步数据库失败测试继续验证。整合首轮编译捕获主线 onFailure 格式错误，已修；不把中间构建失败计为通过。
- 发现 Continue sources 的既有 Koin 注册使用相同未限定接口 key，会相互覆盖；交 route owner 改具名注册并补真实接线测试。DeepRead source_url 由该 owner 做 Room 16→17 可空列迁移，已通知 restore owner 保持旧归档兼容与数据集保护。

- Novel 定点集成通过：实际 WorkManager 异步入队失败、重建查询、通知身份、Continue、Runtime 21 项均通过。进一步 review 修复 rewrite/consistency 两条未登记停止的操作（turnJob + finally）、旧失败卡删除新 execution 的竞态（状态/execution CAS）、dismiss 后无法再开新批次面板；`phase0_review` 定向复审通过。
- 扩大路由批次 app 67 项中 66 通过、1 个 DeepRead sourceURL fixture 因固定 1970 时钟被现有 TTL 判断过期，owner 已修 fixture 为 ttlDays=0，待复跑；Novel recovery 7 项通过。日志 `/tmp/amber-parity-phase2-routes-build.log`，未把该批计为全通过。
- 当前阶段中间 APK assembleDebug 通过，日志 `/tmp/amber-parity-phase2-ui-build.log`，已安装模拟器。冷启动真实本地无 WorkManager 的 running fixture → failed，Home 同时显示损坏记录和精确批次；点 Continue 开对应批次、点“知道了”回新批次表单，大字体 1.5 重新打开可用。截图 `parity-artifacts/phase2-home-recovery.png`、`phase2-novel-interrupted.png`、`phase2-novel-new-batch.png`、`phase2-novel-large.png`、`phase2-novel-large-sheet.png`。此 APK 尚不包含后续备份/memory/board gate 收尾，不能作为 Phase2 全量最终产物。
- UI reviewer 精确发现并修复首页搜索触控高度、MiniApp重试异常无反馈、Novel按钮触控高度；根Activity已enableEdgeToEdge，未采纳把MiniApp恢复decorFits改true的未经证实建议。Backup口令/长预览scroll+IME已由独立owner补，待设备复验。
- W06 独立 `runtime_audit` 发现仅Chat gate不够：cancel后terminal/ledger写、独立memory extraction、启用的Board WorkManager、MiniApp bridge存在真实旧payload写入。共享epoch接口复用现有gate；restore owner处理Chat/run/tool/MiniApp/thread，memory和board两个owner分工接短持久写入，不在网络/LLM期间持锁。阶段门仍未通过。

- W15 Novel 真实交换三段通过：iOS 生产 exporter 12 files → Android 生产 importer/edit/exporter 12 files → iOS 生产 importer/validator，再导出 13 files（重建章节 plot module）。Swift fixture 另核验 plot summary/outline、upcoming beat、confirmed plan。详见 `docs/audits/phase2-exchange.md`。iOS UI 接受工作区文件夹，Android ZIP 需先解压；两端本地 ledger/jobs/sessions 不在交换树内，未宣称运行任务迁移。
- 普通对话实际模拟器 SAF 导入：iOS 生产 storage 生成的合成文档经 stored ZIP 封装，Android 预览 1 个新增并确认后，Room 实际为 1 个 conversation / 1 个 message node。发现存储卡仍 Loading、成功文案未刷新，新增真实 CardGroup Compose 状态切换测试定位；问题尚未判定或验收。
- W06 收尾补查真实删除入口：FilesManager 的 attachment/chat_images unlink 与 managed row 在同一短 gate；ConversationRepository/ChatService 的异步 cleanup 传递旧 epoch；SessionCleanupManager 原始 SQL 清理路径补 gate 并携带预览 epoch，避免旧预览删除恢复后的数据。独立 owner 测试及 review 继续进行。
- 本轮两次统一回归被新增 block-body 返回类型编译问题挡住（Novel VM 测试、FilesManager），均已定点修正，正在重跑；这些失败不计入通过数量。
- 普通对话生产 codec 反向验证完成：Android `ConversationExchangeInteropTest` 1/0/0，真实输出交给 iOS `JsonConversationStorage.importConversations` 后重读，标题为 Android 修改后的值且消息保留。双端 ZIP 和 stdout 已保存于 `parity-artifacts/phase2-*-conversations.zip`、`phase2-conversation-ios-reimport.log`；Swift runner 保存在 `scripts/conversation-exchange/`。
- `phase0_review` 定向复审通过 W04 pinned DeepRead、点击前已删除 Chat/ImageGen 不导航，及 W15 SAF/codec IO、取消清理 busy、同一 gate 内冲突重检。极窄的查存在后再并发删除竞态未被该 Home 补丁消除，未宣称实现底层“只能打开、不能创建”的新 Chat 契约。
- 集中回归 app 116 + settings 6，共 122 项，118 通过、4 失败、0 跳过（`/tmp/amber-parity-phase2-closeout-tests.log`）。通过项包括真实 SyncArchiveManager 4 项、Novel VM 4 项、StorageCleanup 9 项、CapabilityFlags 6 项。失败为 CardGroup 动态更新、两项 Exchange summary SQL 的 Robolectric json_extract、HotList 领域对象/实体断言比较；对应修复后继续复验，不能把该批写成全通过。
- CardGroup 第一次 NonSkippable 注解修复被真实测试证伪，已删除该尝试，改为直接渲染 composable item/rawItem，移除普通 mutableList 注册投影。分组保留 18dp 外圆角、2dp 行内圆角及 1dp 间距；测试增加 Loading→成功→Loading→第二次成功，最终 APK 将复核整个存储/备份卡片布局。
- `runtime_audit` 复审通过 SessionCleanup 旧预览 epoch、managed membership、保留其它会话共享附件、路径去重及不可取消删除提交；真实 Room QueryCallback 在首个 DELETE 调用点取消任务的回归已通过。没有为物理 IO/DB 故障另建 journal，原有明确失败/重试行为保留。
- Q10 / SyncProviderV2 现按能力单独默认开启，显式 false 升级后保持关闭。`phase0_review` 确认 DI→VM flag→WebDAV/本地文件夹 UI 与关闭时 VM guard 闭环；6 项 flags 测试通过。真实 WebDAV/Google 账号烟测仍未进行，不把 Mock provider 测试计为实网验证。

- 前批 4 项失败已定点复验：CardGroup 动态更新 1、ConversationExchangeService 3、HotList 2，共 6 项全部通过，assembleDebug 同批成功（`/tmp/amber-parity-phase2-ui-final-build.log`）。22:31 APK 实际安装后存储统计、导入成功反馈均正常；UI reviewer 复核通过。
- 实际 SAF 选择路径→自定义口令→确认口令→加密导出成功，1.5 倍字体与键盘弹出时操作可见；截图已归档 `parity-artifacts/phase2-backup-export-*.png`。WebDAV 输入表单亦完成大字体/IME 验证，但没有使用真实远端账号。

- W06 最后收尾：Chat 同步 update 只发布内存投影，物理附件清理归 suspend save/delete owner；Council 和 ThreadGraph 的长任务在首读前捕获同一 restore epoch。独立复审及最终回归中。
- 设备迁移初测因中间 KSP 误改历史 16.json 而重复 source_url 失败；确认该历史文件不属于用户初始 WIP 后恢复 HEAD 原件，生产迁移未加存在判断兜底。该次 Gradle connected 还自动选中了已连接的 M154FF（与模拟器均失败）；后续固定 ANDROID_SERIAL=emulator-5554，只在合成模拟器运行。此次不计迁移通过。
- modelcouncil 模块 CouncilRoomManagerTest 7 项已通过（`/tmp/amber-parity-phase2-runtime-migration.log`）；同批 app JVM 未执行完，另批重新运行。

- 最终 runtime JVM 43 项全部通过，0 失败/跳过，包含网络恢复 barrier、ThreadGraph 长任务 epoch、Archive 实际恢复、Backup VM 清理及通知（`/tmp/amber-parity-phase2-runtime-final.log`）；同批 assembleDebug 成功。Council 模块 7 项另批通过。
- 历史 schema 修复后，指定 emulator-5554 的 Room16→17 真设备迁移 1 项通过（`/tmp/amber-parity-phase2-migration-final.log`），`phase2_routes` 独立确认 schema/SQL 一致。
- 最新 APK 已重新安装；HomeHeader 删除冗余 weight Spacer 后默认字体日期完整、1.5 倍字体仍合理截断且按钮不重叠，截图 `phase2-home-final.png` / `phase2-home-large-final.png`。字体已恢复1.0；原有功能轨道大字体标签截断纳入 Phase6 全局 UI 核查。

- `runtime_audit` 最终复审确认 Chat/ThreadGraph 无旧 epoch durable 漏写；新增窄场景修复：失败且无数据提交时清除 deferred epoch（保留 tombstone），成功/partial 后迟到 purge 被 tombstone guard 拒绝；purge 首先捕获 invocation epoch，避免 guard 与 map 读取之间的 restore 竞态。该 ChatService handler 以独立源码复审验证，未宣称实际构造 ChatService 的集成测试。两项只镜像 handler 的测试已删除，复用真实 gate/Files 回归。
- UI reviewer `phase1_ui_review` 最终通过加密导出/键盘、WebDAV大字体、存储/导入动态卡片以及HomeHeader默认/大字体实屏，无新的几何阻断。

- 最终 gate/Files 9 项、assembleDebug 全通过（`/tmp/amber-parity-phase2-purge-final.log`）；`phase0_review` 对最后删除时序定向复审通过。Phase2阶段门完成。真实云账号与全量备份跨端互导不属于已验证结论，W15支持子集详见专项报告。

### Phase 3（完成）

W07由phase1_models实施；W08由browser_miniapp_parity实施；W09由phase2_routes实施。接口与文件所有权参考 `2026-09-09-phase3-browser-contract.md`。主任务负责集成、受控网页/设备验证和阶段review，不并行执行Gradle。

- Phase3 分工细化：W08 owner/SessionHandle/WebViewPool/popup/DI 保持 browser_miniapp_parity；独立页面/卡片/Screen/RouteActivity 交 phase1_attachments，避免 owner 与工具接线被 UI 实现串行阻塞。W07 仅子代理专属 Cot/card，不改 ChatPage；W09 仅工具与窄 run 参数接线。
- 主线新增 `scripts/webmount-parity/` 合成网页（JS 语法检查通过），以及 `WebMountParityDeviceTest` 实际 WebView/bridge 测试，待生产实现就绪统一运行。受控服务仅监听本机127.0.0.1:18765，并通过指定模拟器adb reverse访问，不连接真实网站账号。

- 首轮生产编译捕获3个Lucide扩展import与1个receipt参数类型错误，定点修复后app生产编译通过。首轮app定点25项中23通过、2失败（新增JUnit非void返回与Integer/Long断言），settings flags 7项通过；fixture已修，第二轮统一回归中。日志 `/tmp/amber-parity-phase3-first-compile.log`、`/tmp/amber-parity-phase3-first-tests.log`。
- 主线检查补出真实断点：飞书snapshot/network工具绕过owner；只读WebView系统返回可改历史；JS confirm持有AGENT lease使人工无法接管；显式重开仅创建空白handle。按文件owner定点修复，并补实际createClickTool→人工resolve及重开加载设备用例，未把直接调用底层resolve当作产品流程通过。

- 第二轮app定点42项41通过，idle mailbox followup的PERSISTED断言失败，owner定位中；真实设备APK构建成功。指定模拟器首轮WebView 11项7通过4失败：重开仍IDLE、headless JS dialog resolve调度、真实tool交还后dialog同问题，以及popup等待默认可见区域造成的fixture问题。已分别修production/main-thread调度与测试visible_only，不把失败写成通过。日志 `/tmp/amber-parity-phase3-second-tests.log`、`/tmp/amber-parity-phase3-device-build.log`、`/tmp/amber-parity-phase3-first-device.log`。
- W07独立review发现child scope需逐generation唯一且终态释放、旧runner迟到回调identity、interrupt任务/事件收尾、冷启动直接followup的DELIVERED重排队4项阻断，均交原owner定向修复；阶段门尚未通过。

- W07四项逻辑修复已由phase0_review定向复审通过；尚待统一测试，期间其他UI owner的新测试import/Council helper中间状态曾挡住编译，未计通过。W08实屏沿Home站点→恢复卡→页面内重开成功，草稿输入/保存/交还、1.5倍字号/IME五图经独立UIreview通过。实际popup打开及切换可用，但关闭后返回原页发现黑屏，交UI owner按真实WebView identity修复；因此尚未宣布W08完整通过。字体已恢复1.0。
- W08/W09独立调用链review指出LRU reservation/pin竞态、取消精确handle、旧run取消误伤HUMAN新dialog、物理Main dispatch需与lease校验原子化；另补scoped tab_list、导航/写请求回执、取消透明传播。按现有owner/token/工具小范围收口。正常COMPLETED保留已明确human handoff、取消/失败清理；新增实际工具→正常endRun→HUMAN与取消后迟到confirm用例。
- 主线收口站点增删单次确认：PermissionDecisionResolver沿既有foreground强制确认模式，优先于全局unattended开关，仅wm_site_add/remove受影响；新增真实resolver回归3项。

- 最终集中 JVM 90 项全部通过，0 失败/跳过；同批 app/androidTest APK 构建成功（`/tmp/amber-parity-phase3-closeout.log`）。前批4项失败已精确修复：clickable内部48dp语义边界、Council旧start/running与真实终态读取/冷transcript的优先级；没有改变Council任务retry领域含义。
- WebView 设备最终16项全部通过（`/tmp/amber-parity-phase3-final-device.log`），含复用已有handle取消后保留页面/草稿、新建取消清orphan、reservation期间LRU保护、旧lease物理dispatch拒绝、正常completed保留human handoff、取消后迟到确认无效及opener/cookie/popup关闭。仅固定emulator-5554、合成本地网页，未使用真实SSO。
- 最新UI实屏 `phase3-browser-auto-reopen-final.png` 确认首次重开直接加载；`phase3-browser-confirm-final.png` 确认弹窗布局及取消返回；`phase3-browser-popup-returned-final.png` 确认popup关闭后原页面恢复且显示合成登录完成。旧 `phase3-browser-popup-returned.png` 留作黑屏失败证据。根因是旧DisposableEffect清理新WebView，已按实际WebView实例key修复。
- W08/W09 reviewer `phase2_restore` 对原最终清单复审无新阻断；追加的“物理dispatch后、WebChrome回调前结束run”假设要求用真实WebView独立复现，尚未将假设转化为新框架。Phase3门等待最后UI结论和该定点证据裁定。

- 追加late-dialog已用真实WebView复现失败，再用最小无lease新dialog取消规则修复；已存在人工handoff不变。最终两个device class共17项全部通过（`/tmp/amber-parity-phase3-device-closeout.log`），页面实际confirm返回false亦有断言。独立reviewer复核通过；幂等host-shim安装未当作业务写动作扩改。最终UI reviewer三图复审通过，Phase3阶段门完成。

### Phase 4（用户主动暂停，待接手）

采用 `2026-09-09-phase4-miniapp-implementation-boundaries.md` 的双端实际契约，协议/授权/JS、原生owner/runner、Q03/Q04/Q05页面修复按文件独占分工。主线负责集成、实际JS桥/设备验证及独立复审。已确认工程直接依赖ZXing core并有QRCodeWriter，无需新增二维码依赖。

- 2026-09-10 用户明确暂停连续实施，改为要求交接文档和下一位AI的prompt。当前不继续Phase4–9。详见 `docs/handoff/2026-09-10/README.md`。Phase4协议/native尚未落码；Q03/Q04/Q05已有UI与helper测试改动但未编译/运行/独立review，不能沿用Phase3通过结论。
- 本次临时网页服务已停止，adb reverse已移除，字体已恢复1.0；本次headless只读模拟器已关闭且未保存快照。没有新增commit/发布，没有要求下一位AI重复确认已授权范围。
